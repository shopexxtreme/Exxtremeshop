"use client";

import { CartProvider } from '@/lib/cartContext';
import './globals.css';

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="pt-BR">
      <head>
        <title>STORE - Loja de Roupas e Acessórios</title>
        <meta name="description" content="Loja online de roupas e acessórios com as melhores marcas e preços" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
      </head>
      <body>
        <CartProvider>
          {children}
        </CartProvider>
      </body>
    </html>
  );
}
