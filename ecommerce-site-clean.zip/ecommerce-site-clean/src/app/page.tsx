"use client";

import React from 'react';
import Header from '@/components/Header';
import Navigation from '@/components/Navigation';
import Banners from '@/components/Banners';
import ProductGrid from '@/components/ProductGrid';
import Footer from '@/components/Footer';

export default function Home() {
  return (
    <main className="min-h-screen bg-gray-100">
      <Header />
      <Navigation />
      <div className="animate-fade-in">
        <Banners />
        <ProductGrid />
      </div>
      <Footer />
    </main>
  );
}
