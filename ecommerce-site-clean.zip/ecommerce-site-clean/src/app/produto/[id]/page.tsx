"use client";

import React from 'react';
import { useParams } from 'next/navigation';
import Header from '@/components/Header';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';
import { useCart } from '@/lib/cartContext';

// Dados de exemplo para produtos
const productsData = [
  {
    id: '1',
    name: 'Camiseta Premium Preta',
    image: '/images/placeholder-shirt.svg',
    price: 149.90,
    originalPrice: 339.00,
    discount: 56,
    description: 'Camiseta premium de alta qualidade, confeccionada com tecido 100% algodão. Confortável e durável, perfeita para o dia a dia.',
    sizes: ['P', 'M', 'G', 'GG'],
    colors: ['Preto'],
    category: 'camisas'
  },
  {
    id: '2',
    name: 'Camiseta Premium Branca',
    image: '/images/placeholder-shirt.svg',
    price: 149.90,
    originalPrice: 339.00,
    discount: 56,
    description: 'Camiseta premium de alta qualidade, confeccionada com tecido 100% algodão. Confortável e durável, perfeita para o dia a dia.',
    sizes: ['P', 'M', 'G', 'GG'],
    colors: ['Branco'],
    category: 'camisas'
  },
  {
    id: '3',
    name: 'Camiseta Premium Vermelha',
    image: '/images/placeholder-shirt.svg',
    price: 149.90,
    originalPrice: 339.00,
    discount: 56,
    description: 'Camiseta premium de alta qualidade, confeccionada com tecido 100% algodão. Confortável e durável, perfeita para o dia a dia.',
    sizes: ['P', 'M', 'G', 'GG'],
    colors: ['Vermelho'],
    category: 'camisas'
  },
  {
    id: '4',
    name: 'Bermuda Premium Preta',
    image: '/images/placeholder-shorts.svg',
    price: 199.90,
    originalPrice: 399.00,
    discount: 50,
    description: 'Bermuda premium de alta qualidade, confeccionada com tecido resistente e confortável. Ideal para diversas ocasiões.',
    sizes: ['38', '40', '42', '44'],
    colors: ['Preto'],
    category: 'bermudas'
  },
  {
    id: '5',
    name: 'Calça Premium Preta',
    image: '/images/placeholder-pants.svg',
    price: 249.90,
    originalPrice: 499.00,
    discount: 50,
    description: 'Calça premium de alta qualidade, confeccionada com tecido resistente e confortável. Ideal para diversas ocasiões.',
    sizes: ['38', '40', '42', '44'],
    colors: ['Preto'],
    category: 'calcas'
  }
];

export default function ProductPage() {
  const params = useParams();
  const productId = params?.id as string;
  const { addItem } = useCart();
  
  // Encontrar o produto pelo ID
  const product = productsData.find(p => p.id === productId) || productsData[0];
  
  const [selectedSize, setSelectedSize] = React.useState('');
  const [selectedColor, setSelectedColor] = React.useState('');
  const [quantity, setQuantity] = React.useState(1);
  
  const handleAddToCart = () => {
    if (!selectedSize) {
      alert('Por favor, selecione um tamanho');
      return;
    }
    
    addItem({
      id: product.id,
      name: `${product.name} - ${selectedSize}`,
      price: product.price,
      quantity: quantity,
      image: product.image
    });
    
    alert('Produto adicionado ao carrinho!');
  };
  
  return (
    <div>
      <Header />
      <Navigation />
      
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row gap-8">
          {/* Imagem do produto */}
          <div className="md:w-1/2">
            <div className="bg-gray-100 rounded-lg h-96 flex items-center justify-center">
              {product.image ? (
                <img 
                  src={product.image} 
                  alt={product.name} 
                  className="w-full h-full object-contain"
                />
              ) : (
                <div className="text-gray-500 text-center">
                  <div className="text-6xl mb-4">👕</div>
                  <span>Imagem do produto</span>
                </div>
              )}
            </div>
          </div>
          
          {/* Informações do produto */}
          <div className="md:w-1/2">
            <h1 className="text-2xl font-bold mb-2">{product.name}</h1>
            
            <div className="flex items-center mb-4">
              <span className="text-2xl font-bold text-gray-900 mr-3">
                R$ {product.price.toFixed(2).replace('.', ',')}
              </span>
              
              {product.originalPrice > product.price && (
                <span className="text-lg text-gray-500 line-through">
                  R$ {product.originalPrice.toFixed(2).replace('.', ',')}
                </span>
              )}
              
              {product.discount > 0 && (
                <span className="ml-3 bg-green-500 text-white text-sm font-bold px-2 py-1 rounded">
                  -{product.discount}%
                </span>
              )}
            </div>
            
            <p className="text-gray-600 mb-6">{product.description}</p>
            
            {/* Seleção de tamanho */}
            <div className="mb-6">
              <h3 className="font-medium mb-2">Tamanho:</h3>
              <div className="flex flex-wrap gap-2">
                {product.sizes.map((size) => (
                  <button
                    key={size}
                    onClick={() => setSelectedSize(size)}
                    className={`w-12 h-12 border rounded-md flex items-center justify-center ${
                      selectedSize === size 
                        ? 'border-orange-500 bg-orange-50 text-orange-500' 
                        : 'border-gray-300 hover:border-gray-400'
                    }`}
                  >
                    {size}
                  </button>
                ))}
              </div>
            </div>
            
            {/* Seleção de cor (se houver mais de uma) */}
            {product.colors.length > 1 && (
              <div className="mb-6">
                <h3 className="font-medium mb-2">Cor:</h3>
                <div className="flex flex-wrap gap-2">
                  {product.colors.map((color) => (
                    <button
                      key={color}
                      onClick={() => setSelectedColor(color)}
                      className={`px-4 py-2 border rounded-md ${
                        selectedColor === color 
                          ? 'border-orange-500 bg-orange-50 text-orange-500' 
                          : 'border-gray-300 hover:border-gray-400'
                      }`}
                    >
                      {color}
                    </button>
                  ))}
                </div>
              </div>
            )}
            
            {/* Quantidade */}
            <div className="mb-6">
              <h3 className="font-medium mb-2">Quantidade:</h3>
              <div className="flex items-center">
                <button 
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center hover:bg-gray-300"
                >
                  -
                </button>
                <span className="mx-4 w-8 text-center">{quantity}</span>
                <button 
                  onClick={() => setQuantity(quantity + 1)}
                  className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center hover:bg-gray-300"
                >
                  +
                </button>
              </div>
            </div>
            
            {/* Botão de compra */}
            <div className="flex flex-col sm:flex-row gap-4">
              <button 
                onClick={handleAddToCart}
                className="flex-1 bg-orange-500 text-white py-3 px-6 rounded-lg hover:bg-orange-600 transition-colors"
              >
                Adicionar ao Carrinho
              </button>
              <button className="flex-1 bg-green-500 text-white py-3 px-6 rounded-lg hover:bg-green-600 transition-colors">
                Comprar Agora
              </button>
            </div>
            
            {/* Informações adicionais */}
            <div className="mt-8 border-t border-gray-200 pt-6">
              <div className="flex items-center mb-3">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2 text-green-500">
                  <path d="M21 10V8a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-2" />
                  <path d="M16 2v4" />
                  <path d="M8 2v4" />
                  <path d="M3 10h18" />
                </svg>
                <span>Frete grátis para todo o Brasil</span>
              </div>
              <div className="flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2 text-green-500">
                  <circle cx="9" cy="21" r="1" />
                  <circle cx="20" cy="21" r="1" />
                  <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6" />
                </svg>
                <span>Satisfação garantida ou seu dinheiro de volta</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <Footer />
    </div>
  );
}
