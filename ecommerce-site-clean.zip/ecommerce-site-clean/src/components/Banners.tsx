import React from 'react';
import Link from 'next/link';
import Image from 'next/image';

const HeroBanner = () => {
  return (
    <div className="relative w-full h-[400px] bg-gradient-to-r from-gray-900 to-orange-500 overflow-hidden">
      <div className="container mx-auto px-4 h-full flex items-center">
        <div className="w-1/2 text-white z-10">
          <h1 className="text-5xl font-bold mb-4">SEJA MUITO BEM VINDOS!</h1>
          <p className="text-xl mb-6">FRETE GRÁTIS</p>
          <div className="flex items-center">
            <span className="text-lg mr-2">@loja_oficial</span>
          </div>
        </div>
        <div className="w-1/2 relative h-full">
          <div className="absolute right-0 top-1/2 transform -translate-y-1/2">
            <div className="bg-orange-400 p-6 rounded-lg shadow-lg">
              <h2 className="text-2xl font-bold text-white mb-2">PARCELE EM ATÉ 12X</h2>
              <p className="text-white mb-4">PAGAMENTO RÁPIDO E SEGURO</p>
              <div className="flex space-x-2">
                <div className="w-10 h-6 bg-blue-600 rounded"></div>
                <div className="w-10 h-6 bg-yellow-500 rounded"></div>
                <div className="w-10 h-6 bg-red-600 rounded"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const CategoryBanner = () => {
  const categories = [
    { name: 'Camisas', image: '/images/placeholder-shirt.svg' },
    { name: 'Bermudas', image: '/images/placeholder-shorts.svg' },
    { name: 'Calças', image: '/images/placeholder-pants.svg' },
    { name: 'Conjuntos', image: '/images/placeholder-outfit.svg' },
    { name: 'Tênis', image: '/images/placeholder-shoes.svg' }
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      <h2 className="text-2xl font-bold mb-6 border-b-2 border-orange-500 pb-2">Nossas coleções</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
        {categories.map((category, index) => (
          <Link href={`/categoria/${category.name.toLowerCase()}`} key={index} className="group">
            <div className="bg-gray-900 rounded-full p-4 aspect-square flex items-center justify-center relative overflow-hidden group-hover:bg-gray-800 transition-colors">
              <div className="text-orange-500 border-2 border-orange-500 rounded-full w-full h-full flex items-center justify-center">
                <span className="text-lg font-medium">{category.name}</span>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
};

const CollectionBanner = ({ title, image, buttonText }) => {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="bg-gradient-to-r from-gray-900 to-orange-500 rounded-lg overflow-hidden">
        <div className="flex flex-col md:flex-row items-center">
          <div className="w-full md:w-1/2 p-8 text-white">
            <h2 className="text-4xl font-bold mb-4">{title}</h2>
            <p className="text-xl mb-6">COLLECTION</p>
            <button className="bg-black text-white px-6 py-2 rounded hover:bg-gray-800 transition-colors">
              {buttonText || 'VER MAIS'}
            </button>
          </div>
          <div className="w-full md:w-1/2 p-4">
            {/* Placeholder for image */}
            <div className="bg-gray-800 h-64 rounded-lg flex items-center justify-center">
              <span className="text-white">Imagem da coleção</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const Banners = () => {
  return (
    <div>
      <div className="w-full">
        <img 
          src="/images/hero-banner.svg" 
          alt="Banner principal" 
          className="w-full h-auto"
        />
      </div>
      <CategoryBanner />
      <CollectionBanner title="CAMISETAS" buttonText="VER MAIS" />
    </div>
  );
};

export default Banners;
