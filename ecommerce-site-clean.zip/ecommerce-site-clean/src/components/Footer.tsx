import React from 'react';
import Link from 'next/link';

const Footer = () => {
  return (
    <footer className="bg-gray-800 text-white pt-10 pb-6">
      {/* Benefícios */}
      <div className="container mx-auto px-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-10">
        <div className="flex items-start">
          <div className="mr-4 text-orange-500">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M21 10V8a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-2" />
              <path d="M16 2v4" />
              <path d="M8 2v4" />
              <path d="M3 10h18" />
            </svg>
          </div>
          <div>
            <h3 className="font-bold text-lg mb-2">Envio para todo o Brasil !!</h3>
            <p className="text-gray-300">Envio rápido com código de rastreio via Correios.</p>
          </div>
        </div>
        
        <div className="flex items-start">
          <div className="mr-4 text-orange-500">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="9" cy="21" r="1" />
              <circle cx="20" cy="21" r="1" />
              <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6" />
            </svg>
          </div>
          <div>
            <h3 className="font-bold text-lg mb-2">Satisfação ou Reembolso</h3>
            <p className="text-gray-300">Caso você não fique satisfeito nós devolvemos o seu dinheiro em até 7 dias.</p>
          </div>
        </div>
        
        <div className="flex items-start">
          <div className="mr-4 text-orange-500">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
              <circle cx="12" cy="7" r="4" />
            </svg>
          </div>
          <div>
            <h3 className="font-bold text-lg mb-2">Suporte Profissional</h3>
            <p className="text-gray-300">Equipe de suporte de extrema qualidade para te atender todos os dias da semana.</p>
          </div>
        </div>
        
        <div className="flex items-start">
          <div className="mr-4 text-orange-500">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <rect x="1" y="4" width="22" height="16" rx="2" ry="2" />
              <line x1="1" y1="10" x2="23" y2="10" />
            </svg>
          </div>
          <div>
            <h3 className="font-bold text-lg mb-2">Compra Segura</h3>
            <p className="text-gray-300">Aceitamos Pix e Cartão de Crédito.</p>
          </div>
        </div>
      </div>
      
      {/* Atendimento */}
      <div className="container mx-auto px-4 mb-8">
        <div className="bg-gray-700 rounded-lg p-6">
          <h3 className="text-xl font-bold mb-4 border-b border-gray-600 pb-2">ATENDIMENTO AO CLIENTE</h3>
          <div className="mb-4">
            <p className="font-bold">SAC (Serviço de Atendimento ao Consumidor)</p>
          </div>
          <div className="mb-2">
            <p><span className="font-bold">E-mail:</span> suporte@loja.com</p>
          </div>
          <div>
            <p><span className="font-bold">WhatsApp:</span> +55 11 99999-9999</p>
          </div>
        </div>
      </div>
      
      {/* Aviso */}
      <div className="container mx-auto px-4 text-center text-sm text-gray-400 mb-6">
        <p>Preços e condições de pagamento exclusivos para compras neste site oficial, podendo variar com o tempo da oferta. Evite comprar produtos mais baratos ou de outras lojas.</p>
        <p className="mt-2">Caso você compre os mesmos produtos em outras lojas, não nos responsabilizamos por quaisquer problemas.</p>
      </div>
      
      {/* Copyright */}
      <div className="container mx-auto px-4 text-center text-sm text-gray-500 border-t border-gray-700 pt-6">
        <p>© {new Date().getFullYear()} STORE. Todos os direitos reservados.</p>
      </div>
    </footer>
  );
};

export default Footer;
