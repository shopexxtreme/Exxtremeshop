import React from 'react';
import Link from 'next/link';
import { Search, ShoppingCart } from 'lucide-react';

const Header = () => {
  return (
    <header className="bg-gray-800 text-white">
      {/* Informações de envio e satisfação */}
      <div className="bg-gray-700 py-2">
        <div className="container mx-auto flex justify-between px-4">
          <div className="flex items-center">
            <span className="mr-2">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M21 10V8a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-2" />
                <path d="M16 2v4" />
                <path d="M8 2v4" />
                <path d="M3 10h18" />
              </svg>
            </span>
            <span>Envio para todo o Brasil</span>
          </div>
          <div className="flex items-center">
            <span className="mr-2">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="9" cy="21" r="1" />
                <circle cx="20" cy="21" r="1" />
                <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6" />
              </svg>
            </span>
            <span>Satisfação Garantida ou Dinheiro de Volta</span>
          </div>
        </div>
      </div>
      
      {/* Logo, busca e carrinho */}
      <div className="container mx-auto py-4 px-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link href="/" className="text-2xl font-bold">
            <div className="flex items-center">
              <span className="text-3xl font-extrabold">S</span>
              <span className="text-3xl font-extrabold">T</span>
              <span className="text-xl">ORE</span>
            </div>
          </Link>
          
          {/* Busca */}
          <div className="flex-1 mx-10">
            <div className="relative">
              <input 
                type="text" 
                placeholder="O que está buscando?" 
                className="w-full py-2 px-4 rounded-lg text-gray-800 focus:outline-none"
              />
              <button className="absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700">
                <Search size={20} />
              </button>
            </div>
          </div>
          
          {/* Carrinho */}
          <div className="flex items-center">
            <Link href="/cart" className="flex items-center">
              <ShoppingCart size={24} />
              <span className="ml-2">0 Carrinho</span>
            </Link>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
