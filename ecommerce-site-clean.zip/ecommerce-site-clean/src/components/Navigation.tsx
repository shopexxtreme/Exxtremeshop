import React from 'react';
import Link from 'next/link';

const Navigation = () => {
  const categories = [
    { name: 'Home', path: '/' },
    { name: 'Catálogo', path: '/catalogo' },
    { name: 'Camisas', path: '/categoria/camisas' },
    { name: 'Acessórios', path: '/categoria/acessorios' },
    { name: 'Bermudas', path: '/categoria/bermudas' },
    { name: 'Calças', path: '/categoria/calcas' },
    { name: 'Chinelos', path: '/categoria/chinelos' },
    { name: 'Moletons', path: '/categoria/moletons' },
    { name: 'Pratas 925', path: '/categoria/pratas' },
    { name: 'Tênis', path: '/categoria/tenis' },
    { name: 'Conjuntos', path: '/categoria/conjuntos' },
  ];

  return (
    <nav className="bg-gray-900 text-white">
      <div className="container mx-auto px-4">
        <ul className="flex flex-wrap items-center justify-start py-2">
          {categories.map((category, index) => (
            <li key={index} className="mr-1">
              <Link 
                href={category.path}
                className="block px-3 py-2 rounded hover:bg-gray-700 transition-colors"
              >
                {category.name}
              </Link>
            </li>
          ))}
        </ul>
      </div>
    </nav>
  );
};

export default Navigation;
