import React from 'react';
import Link from 'next/link';

interface ProductProps {
  id: string;
  name: string;
  image: string;
  price: number;
  originalPrice: number;
  discount: number;
}

const ProductCard = ({ id, name, image, price, originalPrice, discount }: ProductProps) => {
  return (
    <div className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow">
      {/* Desconto */}
      {discount > 0 && (
        <div className="absolute top-2 left-2 bg-green-500 text-white text-xs font-bold px-2 py-1 rounded">
          -{discount}%
        </div>
      )}
      
      {/* Imagem */}
      <Link href={`/produto/${id}`}>
        <div className="relative h-48 bg-gray-200">
          <div className="absolute inset-0 flex items-center justify-center text-gray-500">
            {image ? (
              <img 
                src={image} 
                alt={name} 
                className="w-full h-full object-cover"
              />
            ) : (
              <span>Imagem do produto</span>
            )}
          </div>
        </div>
      </Link>
      
      {/* Informações */}
      <div className="p-4">
        <Link href={`/produto/${id}`}>
          <h3 className="text-gray-800 font-medium text-sm mb-2 hover:text-orange-500 transition-colors">
            {name}
          </h3>
        </Link>
        
        <div className="flex items-center">
          <span className="text-lg font-bold text-gray-900">
            R$ {price.toFixed(2).replace('.', ',')}
          </span>
          
          {originalPrice > price && (
            <span className="ml-2 text-sm text-gray-500 line-through">
              R$ {originalPrice.toFixed(2).replace('.', ',')}
            </span>
          )}
        </div>
      </div>
    </div>
  );
};

const ProductGrid = () => {
  // Dados de exemplo para produtos
  const products = [
    {
      id: '1',
      name: 'Camiseta Premium Preta',
      image: '/images/placeholder-shirt.svg',
      price: 149.90,
      originalPrice: 339.00,
      discount: 56
    },
    {
      id: '2',
      name: 'Camiseta Premium Branca',
      image: '/images/placeholder-shirt.svg',
      price: 149.90,
      originalPrice: 339.00,
      discount: 56
    },
    {
      id: '3',
      name: 'Camiseta Premium Vermelha',
      image: '/images/placeholder-shirt.svg',
      price: 149.90,
      originalPrice: 339.00,
      discount: 56
    },
    {
      id: '4',
      name: 'Camiseta Premium Azul',
      image: '/images/placeholder-shirt.svg',
      price: 149.90,
      originalPrice: 339.00,
      discount: 56
    },
    {
      id: '5',
      name: 'Bermuda Premium Preta',
      image: '/images/placeholder-shorts.svg',
      price: 199.90,
      originalPrice: 399.00,
      discount: 50
    },
    {
      id: '6',
      name: 'Calça Premium Preta',
      image: '/images/placeholder-pants.svg',
      price: 249.90,
      originalPrice: 499.00,
      discount: 50
    },
    {
      id: '7',
      name: 'Tênis Premium Preto',
      image: '/images/placeholder-shoes.svg',
      price: 299.90,
      originalPrice: 599.00,
      discount: 50
    },
    {
      id: '8',
      name: 'Conjunto Premium Preto',
      image: '/images/placeholder-outfit.svg',
      price: 399.90,
      originalPrice: 799.00,
      discount: 50
    }
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold border-b-2 border-orange-500 pb-2">Camisas</h2>
        <Link href="/categoria/camisas" className="text-orange-500 hover:text-orange-600 transition-colors">
          Ver tudo
        </Link>
      </div>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {products.slice(0, 4).map((product) => (
          <ProductCard key={product.id} {...product} />
        ))}
      </div>
      
      <div className="flex items-center justify-between mt-12 mb-6">
        <h2 className="text-2xl font-bold border-b-2 border-orange-500 pb-2">Calças</h2>
        <Link href="/categoria/calcas" className="text-orange-500 hover:text-orange-600 transition-colors">
          Ver tudo
        </Link>
      </div>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {products.slice(4, 8).map((product) => (
          <ProductCard key={product.id} {...product} />
        ))}
      </div>
    </div>
  );
};

export default ProductGrid;
